﻿using UnityEngine;
using UnityEditor;
using System.Collections;

public class PreviewModeWindow : EditorWindow
{

    private bool initialized;
    private Camera previewCamera;


    public void Initialize()
    {
        
    }

}
